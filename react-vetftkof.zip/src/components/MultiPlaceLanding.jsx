import React from "react";
import { motion } from "framer-motion";

export default function MultiPlaceLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-600 to-blue-800 text-white flex flex-col items-center justify-center p-6">
      <motion.h1
        className="text-5xl font-bold mb-6"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        MultiPlace
      </motion.h1>

      <motion.p
        className="text-lg max-w-xl text-center mb-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
      >
        O marketplace completo para vendedores e compradores. Um novo jeito de
        vender qualquer produto, com segurança, facilidade e velocidade — tudo
        em um só lugar.
      </motion.p>

      <motion.div
        className="bg-white text-blue-700 px-6 py-3 rounded-2xl text-lg font-semibold shadow-xl cursor-pointer hover:bg-blue-50"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        Entrar no MultiPlace
      </motion.div>
    </div>
  );
}
