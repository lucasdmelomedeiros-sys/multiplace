import React from "react";
import MultiPlaceLanding from "./components/MultiPlaceLanding";

export default function App() {
  return <MultiPlaceLanding />;
}
