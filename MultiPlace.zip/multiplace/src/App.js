import React from 'react';

export default function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>MultiPlace</h1>
      <p>Loja estilo Shopee — projeto base instalado!</p>
    </div>
  );
}
